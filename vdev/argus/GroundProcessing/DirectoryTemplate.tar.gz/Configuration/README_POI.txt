The point of interest file should be a CSV file (you should use "," as
the deliminator). The file should be named "poi.csv". There is a
template excel file "poi_example.xls" that can be used if desired,
just save the final data as a CSV.

The first row of the CSV file is ignored, this is assumed to be column labels.
Then the first column should be the point name, the second the longitude
and the third the latitude. Longitude and latitude are in decimal degrees,
with negative numbers indicated west longitude or south latitude.
